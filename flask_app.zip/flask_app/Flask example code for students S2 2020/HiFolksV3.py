# Hi folks v3
# Handles a number

from flask import Flask, render_template, request, flash
import os

SUCCESS_MSG = "success"
WARNING_MSG = "warning"
KEY_SIZE = 24
OLD_AGE = 42

app = Flask(__name__)
app.secret_key = os.urandom(KEY_SIZE)

@app.route('/', methods = ['POST', 'GET'])
def home():
    """ Home page handler """

    print(f"DEBUG. Function received method type: {request.method}")
    
    if request.method == 'POST':

        first_name = request.form.get('form_first_name').title()
        last_name = request.form.get('form_last_name').title()
        age = request.form.get('form_age')
        
        if first_name != "" and last_name != "" and age != "":
            if age.isdigit():
                age = int(age)
                if age > OLD_AGE:
                    flash(f"Wow {first_name}, you are old!", SUCCESS_MSG)
                else:
                    flash(f"Welcome {first_name} {last_name}. I see you are {age} years old.", SUCCESS_MSG)
                return render_template("welcome_userv3.html", title="Welcome", form_first_name=first_name, form_last_name=last_name, form_age=age)
            else:
                flash(f"Age {age} should have been a digit!", WARNING_MSG)
        else:
            flash("Please enter your first and last names and age.", WARNING_MSG)

    return render_template("welcome_userv3.html", title="Welcome")


if __name__ == '__main__':
    app.run()


