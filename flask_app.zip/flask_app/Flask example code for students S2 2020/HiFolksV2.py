# Hi folks v2
# Removes spaces

from flask import Flask, render_template, request, flash
import os

SUCCESS_MSG = "success"
WARNING_MSG = "warning"
KEY_SIZE = 24

app = Flask(__name__)
app.secret_key = os.urandom(KEY_SIZE)

@app.route('/', methods = ['POST', 'GET']) 
def home():
    """ Home page handler """

    print(f"DEBUG: Method is: {request.method}")
    print(f"DEBUG: Headers are: {request.headers}")
    print(f"DEBUG: Data is: {request.get_data()}")
    
    if request.method == 'POST':

        # Lets remove spaces
        first_name = request.form.get('form_first_name').strip().title()
        last_name = request.form.get('form_last_name').strip().title()
        
        if first_name != "" and last_name != "":
            flash(f"Welcome {first_name} {last_name}!", SUCCESS_MSG)
            return render_template("welcome_userV2.html", title="Welcome user", form_first_name=first_name, form_last_name=last_name)
        else:
            flash("Please enter your first and last names.", WARNING_MSG)

    return render_template("welcome_userV2.html", title="Welcome")


if __name__ == '__main__':
    app.run()


