# CompareNumbersV1
# Introductory example

import os
from flask import Flask, render_template, request, flash

SUCCESS_MSG = "success"
WARNING_MSG = "warning"
KEY_SIZE = 24

# Create Flask instance and set the session key
app = Flask(__name__)
app.secret_key = os.urandom(KEY_SIZE)

def compare_values(a, b):
    """ Compare values and retun a message string containing the result """

    if a > b:
        return f"{a} is larger than {b}."
    elif a < b:
        return f"{a} is smaller than {b}."
    else:
        return f"{a} is the same as {b}."
    

@app.route('/', methods = ['POST', 'GET'])
def home():
    """ Home page handler """

    print(f"DEBUG. Function received method type: {request.method}")
    
    if request.method == 'POST':
        # Get the data that has been sent via http post
        first_name = request.form.get('form_first_name').title()
        first_num = request.form.get('form_first_number')
        second_num = request.form.get('form_second_number')

        if first_name != "" and first_num != "" and second_num != "":
            # Data has been submitted
            if first_num.isdigit() and second_num.isdigit():
                # Numerical fields are digits so let's convert them to ints
                first_num = int(first_num)
                second_num = int(second_num)
                # Compare the values received and return the results to the browser
                msg = compare_values(first_num, second_num)
                flash(f"{first_name}, {msg}", SUCCESS_MSG)
                return render_template("CompareNumbersV1.html", title="Home", form_first_name=first_name, form_first_number=first_num, form_second_number=second_num)
            else:
                # Not digits
                flash(f"Numbers only please.", WARNING_MSG)
        else:
            # Not all the data was received
            flash("Please enter your first name and two numbers please.", WARNING_MSG)

    return render_template("CompareNumbersV1.html", title="Home")

if __name__ == '__main__':
    app.run()


