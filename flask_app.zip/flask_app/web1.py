import sys, os
from flask import Flask
if sys.platform.lower() == 'win32':
    os.system('color')

app = Flask(__name__)

@app.route('/')
def home():
    return "Hi Folks."

app.run()
