# web2.py

from flask import Flask
app = Flask(__name__)
app.debug = True

@app.route('/')
def home():
    return "Hi Folks!"

app.run()
