# web3.py
from flask import Flask

app = Flask(__name__)
app.debug = True

@app.route('/')
def home():
    """ Home function for handling /""" 
    return "Hi folks!"

@app.route('/version')
def show_version():
    """ Show version handler """ 
    return "Version 1.0"

app.run()
