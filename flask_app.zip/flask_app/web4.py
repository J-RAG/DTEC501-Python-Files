# web4.py

from flask import Flask, request

app = Flask(__name__)
app.debug = True

@app.route('/')
def home():
    """ Home function for handling / """ 
    print(request.args)
    print(type(request.args))

    return("Now supporting args")

    
@app.route('/version')
def show_version():
    """ Show version handler """ 
    return "Version 1.1"

app.run()
