# web5.py

from flask import Flask, request

app = Flask(__name__)
app.debug = True

@app.route('/')
def home():
    """ Home function for handling / """ 
    if len(request.args) > 0:
        msg = arg_handler(request.args)
        return msg
    else:
        return "No arguments were specified."
    
def arg_handler(arg):
    user_name = arg.get("name")
    if user_name != None:
        return f"Hi {user_name}. :-)"
    else:
        return "Name not specified."
    
@app.route('/version')
def show_version():
    """ Show version handler """ 
    return "Version 1.1"

app.run()
