# Assement3B Question 3
# by JulanRayAvilaGutierrez, jra0108@arastudent.ac.nz

import os
from flask import Flask, render_template, request, flash

# get_demerit_points() constants (*question 1 code)
SCHOOL_HOLIDAY_LIMIT = 4
TRAILER_LIMIT = 5

DISCRESSION_LIMIT = 10
EXCESSIVE_LIMIT_TWO = 20
EXCESSIVE_LIMIT_THREE = 30
EXCESSIVE_LIMIT_FOUR = 35

SPEED_PENALTY_ONE = 10 
SPEED_PENALTY_TWO = 20
SPEED_PENALTY_THREE = 35
SPEED_PENALTY_FOUR = 40
SPEED_PENALTY_FIVE = 50

# Flask Constants
SUCCESS_MSG = "success"
WARNING_MSG = "warning"
KEY_SIZE = 24

INVALID_INPUT_MSG = "Both speeds must be numerical values."


# Create Flask instance
app = Flask(__name__)
app.secret_key = os.urandom(KEY_SIZE)
app.debug = True

# get_demerit_points() code (*question 1 code)
def getspeed_penalty(driving_speed, speed_limit, penalty_points):
    """
        (subfunction) updates and returns the amount of penalty points depending how fast the driver
        was speeding past the speed limit
    """

    if driving_speed > speed_limit and driving_speed <= speed_limit + DISCRESSION_LIMIT:
        penalty_points = SPEED_PENALTY_ONE
        
    elif driving_speed > speed_limit + DISCRESSION_LIMIT and driving_speed <= speed_limit + EXCESSIVE_LIMIT_TWO:
        penalty_points += SPEED_PENALTY_TWO
        
    elif driving_speed > speed_limit + EXCESSIVE_LIMIT_TWO and driving_speed <= speed_limit + EXCESSIVE_LIMIT_THREE:
        penalty_points += SPEED_PENALTY_THREE
        
    elif driving_speed > speed_limit + EXCESSIVE_LIMIT_THREE and driving_speed <= speed_limit + EXCESSIVE_LIMIT_FOUR:
         penalty_points += SPEED_PENALTY_FOUR
    else:
        penalty_points += SPEED_PENALTY_FIVE
    return penalty_points


def get_demerit_points(
    driving_speed,
    speed_limit,
    light_trailer=False,
    school_zone=False,
    holiday_period=False
    ):
    """
        Works out the demerit (penalty) points for a
        driving speed in a particular speed limited zone.
    """
    mandatory_penalty = False
    penalty_points = 0

    # Base check if driver exceeded the speed limit
    if driving_speed > speed_limit:
        # Mandatory penalty check
        if any([
            (school_zone or holiday_period) and driving_speed > speed_limit + SCHOOL_HOLIDAY_LIMIT,
            light_trailer and driving_speed > speed_limit + TRAILER_LIMIT,
            driving_speed > speed_limit + DISCRESSION_LIMIT
            ]):
            mandatory_penalty = True

        # Calculate penalty points     
        penalty_points = getspeed_penalty(driving_speed, speed_limit, penalty_points)
            
    return mandatory_penalty, penalty_points

# 404 handler
@app.errorhandler(404) 
def page_not_found(e): 
  return render_template("404WithTimer.html") 

@app.route('/', methods = ['POST', 'GET'])
def home():
    """ main page handler """

    print(f"DEBUG. Function received method type: {request.method}")

    if request.method == 'POST':
        # Get the data that has been sent via http post
        driving_speed = request.form.get('form_driving_speed')
        speed_limit = request.form.get('form_speed_limit')
        trailer = request.form.get('form_trailer')
        school = request.form.get('form_school')
        holiday = request.form.get('form_holiday')

        if driving_speed == "" and speed_limit == "":
            # empty input entry message
            flash(INVALID_INPUT_MSG, WARNING_MSG)
        elif not (driving_speed.strip().replace(".","").isdigit() and speed_limit.strip().replace(".","").isdigit()):
            # Non numerical entry
            flash(INVALID_INPUT_MSG, WARNING_MSG)
        else:
            # Valid input
            driving_speed = int(driving_speed.strip())
            speed_limit = int(speed_limit.strip())

            if driving_speed <= speed_limit:
                flash(f"{driving_speed}km/h in a {speed_limit}km/h zone is not speeding", SUCCESS_MSG)

            else:
            
                # Get demerit Points
                demerit_points = get_demerit_points(
                    driving_speed,
                    speed_limit,
                    trailer,
                    school,
                    holiday
                    )
                
                # Mandatory/Discretional penalty out puts
                if demerit_points[0] == True:
                    flash(
                        "The mandatory penalty for driving at "\
                        f"{driving_speed}km/h in a {speed_limit}km/h zone is {demerit_points[1]} points.",
                        WARNING_MSG
                        )
                else:
                    flash(
                        "The discretional penalty for driving at "\
                        f"{driving_speed}km/h in a {speed_limit}km/h zone is {demerit_points[1]} points.",
                        WARNING_MSG
                        )
            
       
    return render_template("Demeritpoints.html", title= "home")

if __name__ == '__main__':
    app.run()

