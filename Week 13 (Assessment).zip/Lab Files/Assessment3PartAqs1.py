# Assessment 3 Part A Question 1 
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

DEFAULT_MIN_LENGTH = 8
MAX_NUM_VOWELS = 2
MIN_NUM_NONALNUM = 2
VOWELS = ("A", "E", "I", "O", "U")
 

def validate_password(password, min_length =DEFAULT_MIN_LENGTH):
    """
        Returns Boolean based on whether the password's validations.
    """
    result = False
    # Password length validation
    if len(password) >= min_length:
        
        # Assigning Validation Variables:
        # Vowel Count
        vow_count = sum(password.upper().count(vowel) for vowel in VOWELS)
        # Uppercase Alpha Char Count
        num_upper = sum(char.isupper() for char in password)
        # Lowercase Aplha Char Count
        num_lower = sum(char.islower() for char in password)
        # Non-Alpha/Numeric Char Count
        num_notalnum = sum(not char.isalnum() for char in password)

        # Validation Checks:
        if all([
            vow_count <= MAX_NUM_VOWELS,
            num_upper > 0 and num_lower > 0,
            num_notalnum >= MIN_NUM_NONALNUM
            ]):
            result = True
            
        # Check for adjacent Numeric characters
        for index in range(len(password) - 1):
            if password[index].isdigit() and password[index + 1].isdigit():
                # Checking if there's a sequence or the two numbers are the same
                if any([
                    int(password[index]) == int(password[index + 1]),
                    int(password[index]) + 1 == int(password[index + 1]),
                    int(password[index]) - 1 == int(password[index + 1])
                    ]):
                    result = False
    return result
