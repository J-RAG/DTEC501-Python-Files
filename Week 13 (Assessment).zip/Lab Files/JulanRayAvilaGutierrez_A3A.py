# Assessment 3 Part A Question 2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

from Assessment3PartAqs1 import validate_password
from tkinter import *
from tkinter.messagebox import *

STATUS_TITLE = "Password status."
PASSWORD_VALID_MSG = "Your password meets the security standard."
PASSWORD_INVALID_MSG = "Your password does not meet the security standard."
NOT_MATCHING_MSG = "The entered passwords do not match"
EXIT_MSG = "Bye"

ABOUT_MSG = "v1 by Julan Ray Avila Gutierrez"

WINDOW_TITLE = "Password Checker"
LEFT_MOUSE_BTN = "<Button-1>"
ENTER_HOTKEY = "<Return>"



def file_clear_option_handler():
    """ Function to handle File/Clear menu """
    password_text.set("")
    pconfirm_text.set("")
    return None

def file_checkpass_option_handler():
    """ Function to handle File/Check password menu """
    # Matching entries check
    if password_text.get() != pconfirm_text.get():
        showwarning(title=STATUS_TITLE, message=NOT_MATCHING_MSG)
    # Empty entries exception
    elif password_text.get().strip() == "" and  pconfirm_text.get().strip() == "":
        showwarning(title=STATUS_TITLE, message=PASSWORD_INVALID_MSG)
    #Password Validation
    else:
        if validate_password(password_text.get()):
            showinfo(title=STATUS_TITLE, message=PASSWORD_VALID_MSG)
        else:
            showwarning(title=STATUS_TITLE, message=PASSWORD_INVALID_MSG)

    # Clear entry Fields (security design decision)
    password_text.set("")
    pconfirm_text.set("")
    
    password_inputbox.focus()
    return None


def exit_menu_handler():
    """ Function to handle File/Exit menu """
    print(EXIT_MSG)
    root_window.destroy()
    return None


def help_about_option_handler():
    """ Function to handle Help/First Option menu """    
    showinfo(title=WINDOW_TITLE, message=ABOUT_MSG)
    return None


def button_pressed_handler(event):
    """ Function to handle File/FirstOption menu """
    file_checkpass_option_handler()
    return None



MAX_TEXT_ENTRY_WIDTH = 8

# Window
root_window = Tk()
root_window.title(WINDOW_TITLE)
root_window.geometry("250x130")
root_window.resizable(width = False, height = False)



# Create the TK string vars for handling the text that is entered into the boxes.
password_text = StringVar()
pconfirm_text = StringVar()

# Password Entry
password_label = Label(root_window,text="Please enter your password.").pack() 
password_inputbox = Entry(root_window, sho= "*", width = MAX_TEXT_ENTRY_WIDTH, textvariable = password_text)
password_inputbox.pack()
password_inputbox.focus()

# Password Confirmation Entry
pconfirm_label = Label(root_window,text="Please re-enter your password.").pack()
pcofirm_inputbox = Entry(root_window, show = "*", width = MAX_TEXT_ENTRY_WIDTH, textvariable = pconfirm_text)
pcofirm_inputbox.pack()

# CHeck Password Button
check_password_btn = Button(root_window, text="Check password")
check_password_btn.pack()
check_password_btn.bind(LEFT_MOUSE_BTN, button_pressed_handler)
root_window.bind(ENTER_HOTKEY, button_pressed_handler)


# Build the menus
menubar = Menu(root_window)

# File menu
file_menu = Menu(menubar, tearoff = 0)
file_menu.add_command(label = "Clear", command = file_clear_option_handler)
file_menu.add_command(label = "Check password", command = file_checkpass_option_handler)

file_menu.add_separator()
file_menu.add_command(label = "Exit", command = exit_menu_handler)
menubar.add_cascade(label="File", menu = file_menu)

# Help menu
help_menu = Menu(menubar, tearoff = 0)
help_menu.add_command(label="About", command = help_about_option_handler)
menubar.add_cascade(label="Help", menu = help_menu)

# Add all the menu's to the window
root_window.config(menu = menubar)



# Handle events
root_window.mainloop() 


