import cmd

class CliExample(cmd.Cmd):
    """Simple command processor example."""

    def __init__(self):
        cmd.Cmd.__init__(self)
        self.prompt = "Option: "
        self.intro  = "Welcome to the menu.  Enter help to get started."

    
    def do_greet(self, line):
        """Display greeting"""
        print("Hi there.")

    
    def do_exit(self, line):
        """Exit"""
        print("Bye.")
        return True

    def default(self, line):
        print(f"{line} is an unknown option.")
        print("Try ? or help for the options.")

    def precmd(self, line):
        return line.lower()

    # Shortcut
    do_hi = do_greet


cli = CliExample()
cli.cmdloop()
