# Lab 2-1-3 
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

