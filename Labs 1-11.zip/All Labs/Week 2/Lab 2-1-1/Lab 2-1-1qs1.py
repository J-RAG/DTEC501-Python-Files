# Lab 2-1-1 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
user_value = int(input("Please enter an integer: "))
increment_value = user_value + 1
print(f"The answer to {user_value} + 1 is {increment_value}")
