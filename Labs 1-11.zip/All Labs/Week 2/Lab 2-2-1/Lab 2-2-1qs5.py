# Lab 2-2-1 question 5
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
COURSE_CODE = "DTEC501"

first_name = input("Please enter your first name: ").strip().capitalize()
last_name = input("Please enter your last name: ").strip().capitalize()
print(f"Pleased to meet you {first_name} {last_name}, welcome to {COURSE_CODE}.")