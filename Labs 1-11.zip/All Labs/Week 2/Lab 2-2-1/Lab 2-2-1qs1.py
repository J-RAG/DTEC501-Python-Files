# Lab 2-2-1 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
user_name = input("Please enter your first name: ").strip().capitalize()
user_value = int(input(f"Hi {user_name}, please enter an integer: "))
increment_value = user_value + 1
print(f"The answer to {user_value} + 1 is {increment_value}")
