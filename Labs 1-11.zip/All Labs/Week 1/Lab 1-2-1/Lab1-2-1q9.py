# Lab 1-1-2 question 9
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

#input name step
user_name = input("Please enter your first name: ")
print("Hi ", user_name, ", pleased to meet you.", sep='')

#input age step 
#assign input type to integer
user_age = int(input("Please enter your age: "))
print("I see you are ", user_age, " years old.", sep='')

#add 2 years to users age
age_in_two_years = user_age + 2
print("In two years you will be ", age_in_two_years, " years old.", sep='')