# Lab 1-1-2 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
first_name = input("Please enter your first name: ")
last_name = input("Please enter your last name: ")
print("Hi")
print(first_name)
print(last_name)
print("Pleased to meet you.")