# Lab 1-1-2 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
print("Hi.")
print("Welcome to ") 
print("DTEC501")