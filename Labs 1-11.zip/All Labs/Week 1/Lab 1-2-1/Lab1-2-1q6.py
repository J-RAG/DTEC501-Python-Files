# Lab 1-1-2 question 6
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
user_number = int(input("Please enter an integer: "))

#add 1 to user_number
final_number = user_number + 1

print("The answer to ", user_number, " + 1 is ", final_number, sep='')