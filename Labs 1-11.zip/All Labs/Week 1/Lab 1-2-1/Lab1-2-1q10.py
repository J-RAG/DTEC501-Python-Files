# Lab 1-1-2 question 10
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

#input name step
user_name = input("Please enter your first name: ")
print("Hi ", user_name, ", pleased to meet you.", sep='')
print()

#input integer step 
#assign input type to integer
first_num = int(input("Please enter the first integer: "))
second_num = int(input("Please enter the second integer: "))
print()

#Output

print("The answer to ", first_num, " + ", second_num, " is ", first_num + second_num, sep='')
print("The answer to ", second_num, " + ", first_num " is ", second_num + first_num, sep='')
print()
print("The answer to ", first_num, " - ", second_num, " is ", first_num - second_num, sep='')
print("The answer to ", second_num, " - ", first_num " is ", second_num + first_num, sep='')
print()
print("The answer to ", first_num, " * ", second_num, " is ", first_num * second_num, sep='')
print("The answer to ", second_num, " * ", first_num, " is ", second_num * first_num, sep='')
print()
print("The answer to ", first_num, " / ", second_num, " is ", first_num / second_num, sep='')
print("The answer to ", second_num, " / ", first_num, " is ", second_num / first_num, sep='')

