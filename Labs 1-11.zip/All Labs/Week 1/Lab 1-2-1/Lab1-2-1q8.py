# Lab 1-1-2 question 8
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

user_name = input("Please enter your first name: ")
user_age = (input("Please enter your age: "))

print("Hi ", user_name, ", pleased to meet you. I see you are ", user_age, " years old.", sep='')