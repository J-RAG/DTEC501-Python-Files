# Lab 1-1-2 question 5	
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
user_number = int(input("Please enter an integer: "))
print("Hi, you entered ", user_number, " which is of type ", type(user_number), sep = '')