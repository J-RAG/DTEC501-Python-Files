# Lab 1-1-2 question 4
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
user_number = input("Please enter an integer: ")
print("Hi, you entered")
print(user_number)