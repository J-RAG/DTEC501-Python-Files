# Lab 1-3-1 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# SyntaxError: invalid character in identifier
# NameError: name 'mesage' is not defined

message = 'Let us get started on DTEC501.“
print(message)