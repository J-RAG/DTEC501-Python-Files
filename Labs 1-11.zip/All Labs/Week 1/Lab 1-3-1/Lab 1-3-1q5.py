# Lab 1-3-1 question 5
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Error at line 1, SyntaxError: invalid syntax 
# Error at line 1, Attempted Missuse of reserved word: class

course_name = "DTEC501"
print(course_name)

