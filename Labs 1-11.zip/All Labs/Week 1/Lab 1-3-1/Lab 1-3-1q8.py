# Lab 1-3-1 question 8
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Error at line 2, SyntaxError: EOL while scanning string literal
# Error at line 4, IndentationError: unexpected indent
# Line 3 and 4 Improper use of naming varaible, use of capital letters 
first = 3
second = 2
product = first * second
print(product)