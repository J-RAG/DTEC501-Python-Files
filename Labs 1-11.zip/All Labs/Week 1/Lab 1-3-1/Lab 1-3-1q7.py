# Lab 1-3-1 question 7
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# IndentationError: unexpected indent, Line 3 and 4
# SyntaxError: cannot assign to literal, Improper use of naming varaible, Line 1 and 2
# After correcting errors from above, new errors were discovered:
# Error at line 3, NameError: name 'one' is not defined
# Error ar line 4, LogicalError: output prints a string "one + two"

first_number = 1
second_number = 2
total = first_number + second_number
print(total)