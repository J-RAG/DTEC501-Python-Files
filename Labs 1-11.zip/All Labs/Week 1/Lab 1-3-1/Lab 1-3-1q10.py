# Lab 1-3-1 question 10
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Error at line 2, NameError: name 'course_code' is not defined. This due to the first line being a comment 
# Clearing the comment hash the following error(s) was found:
# Error at line 1, SyntaxError: EOL while scanning string literal
# Error at line 2, NameError: name 'course_code' is not defined


course_code = "DTEC501"

print(course_code)