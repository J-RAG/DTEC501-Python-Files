# Lab 1-3-1 question 6
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Error at line 1, SyntaxError: cannot assign to literal, also imporper use of naming variable; using capital letters
# Error at line 2, SyntaxError: cannot assign to literal, also imporper use of naming variable; using capital letters
# Error at line 3, SyntaxError: cannot assign to operator

first_number = 1
second_number = 2
total = first_number + second_number 
print(total)


