# Lab 1-3-1 question 2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Line 6, SyntaxError: invalid character in identifier
# Line 7, NameError: name 'mesage' is not defined

message = "Welcome to DTEC501."
print(message)