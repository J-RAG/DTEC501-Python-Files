# Lab 1-3-1 question 9
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Error at line 1, NameError: name 'DTEC501' is not defined
# Error at line 3, NameError: name 'coures_code' is not defined

course_code = "DTEC501"

print(course_code)