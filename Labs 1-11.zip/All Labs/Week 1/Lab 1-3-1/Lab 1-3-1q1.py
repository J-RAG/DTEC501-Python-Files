# Lab 1-3-1 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Line 1, SyntaxError: invalid character in identifier

course_code = "DTEC501"

print(course_code)