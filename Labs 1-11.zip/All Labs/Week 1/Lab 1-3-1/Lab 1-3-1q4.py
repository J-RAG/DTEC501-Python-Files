# Lab 1-3-1 question 4
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
# Error at line 2, SyntaxError: EOL while scanning string literal
# Error at line 1, NameError: name 'message' is not defined

message = 'We are writing code in Python for DTEC501."
print(message)


