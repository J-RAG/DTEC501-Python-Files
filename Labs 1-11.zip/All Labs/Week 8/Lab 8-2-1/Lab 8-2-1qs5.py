# Lab 8-2-1 question 5
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

PASSING_SCORE = 50

x = int(input("Enter your assessment score: "))

if x >= PASSING_SCORE:
    print("You have passed the assessment.")
else:
    print("You have not passed the assessment.")
