# Lab 8-2-1 question 4
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

PASS_MARK = 50

x = int(input("Enter your assessment mark: "))

if x >= PASS_MARK:
    print("You have passed the assessment.")
else:
    print("You have not passed the assessment.")
