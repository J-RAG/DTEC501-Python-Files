# Lab 7-1-2 question 2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def get_option():
    """
        Asks the user to enter an option, removes any extra spaces,
        converts the entered text into lower case and returns it as a string.
    """
    return input("Option: ").strip().lower()