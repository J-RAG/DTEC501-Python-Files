# Lab 7-1-2 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def get_name(message):
    """
        Returns the Contact name as string
    """
    return input(message).strip().title()
