# lab 11-1-2 Question 2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

from lab_11_1_2_module import is_reversible

user_response = input("Please enter a phrase: ").strip()
if is_reversible(user_response):
    print(f"{user_response} is a palindrome.")
else:
    print(f"{user_response} is not a palindrome.")
