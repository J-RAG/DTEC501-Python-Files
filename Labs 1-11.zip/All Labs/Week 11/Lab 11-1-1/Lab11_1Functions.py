# Lab11_1Functions.py
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def starts_with_capital(text_string):
    """ Returns True if the first character of the
        parameter is a capital letter else return
        False.
    """
    # Check if string is Empty
    if text_string == "":
        result = False
    else:
        # Final check if first character is uppercase
        result = text_string[0].isupper()
        
    return result


def is_punctuated_correctly(text_string):
    """
        Returns True if  the last character is a
        full stop or an exclamation mark or a question mark.
        return False if the last character is a character
        other than one of the above.
    """
    # intialise a False statement for the result
    result = False
    # Validatoin check
    if any([text_string.strip().endswith("."),
            text_string.strip().endswith("?"),
            text_string.strip().endswith("!")]):
        result = True # Reassign result if condtion is satisfied
    return result


def is_odd(number):
    """
        Return True  if the number it was passed is an odd number.
        Return False if the number it was passed is an even number.   
    """
    return number % 2 != 0


def is_even(number):
    """
        Return True if the number it was passed is an even number.
        Return False if the number it was passed is an odd number.
    """
    return number % 2 == 0


def convert_to_celsius(temperature_fahrenheit):
    """
        Returns the equivalent temperature using the Celsius scale. 

    """
    offeset = 32
    freezing_point = 5 / 9
    return round((temperature_fahrenheit - offeset) * (freezing_point), 1)


def convert_to_fahrenheit(temperature_celsius):
    """
        Returns the equivalent temperature using the Celsius scale. 

    """
    offeset = 32
    freezing_point = 9 / 5
    return round((temperature_celsius * freezing_point) + offeset, 1)
