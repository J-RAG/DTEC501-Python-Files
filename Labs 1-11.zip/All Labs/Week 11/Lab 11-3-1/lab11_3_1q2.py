# Lab 11-3-1 question 2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import sys
if  len(sys.argv) - 1 == 0:
    print("No arguments were specified.")
else:
    for num, arg in enumerate(sys.argv[1:], start = 1): 
        print(f"Arg#{num}: {arg}")
