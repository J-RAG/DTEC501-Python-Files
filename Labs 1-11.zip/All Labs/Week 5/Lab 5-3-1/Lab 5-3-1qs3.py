# Lab 5-3-1 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def is_odd(number):
    """
        Return True  if the number it was passed is an odd number.
        Return False if the number it was passed is an even number.   
    """
    return number % 2 != 0

##odd_number = 1
##print(is_odd(odd_number))
##
##
##even_number = 2
##print(is_odd(even_number))
