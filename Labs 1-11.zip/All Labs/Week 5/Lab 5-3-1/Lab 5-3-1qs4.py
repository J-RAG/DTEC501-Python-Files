# Lab 5-3-1 question 4
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def is_even(number):
    """
        Return True if the number it was passed is an even number.
        Return False if the number it was passed is an odd number.
    """
    return number % 2 == 0

##odd_value = 1
##print(is_even(odd_value))
##
##even_num = 2
##print(is_even(even_num))
