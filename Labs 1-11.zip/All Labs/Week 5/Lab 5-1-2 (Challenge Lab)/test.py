INVALID_INPUT_MSG = "Integers only please."
PROGRAM_END_MESSAGE = "Bye."
ASTERISK_TO_PRINT = "*"
SPACE_SEPARATOR = " "
EXIT_INPUT = "0"

non_exit_input = True
while non_exit_input:
    num_asterisks = input("Please enter the maximum number of asterisks to be displayed on one line: ").strip()

    if not num_asterisks.isdigit():
        print(INVALID_INPUT_MSG)

    elif num_asterisks == EXIT_INPUT:
        non_exit_input = False

    else:
        for amount in range(1, int(num_asterisks)):
            print(f"{SPACE_SEPARATOR * (int(num_asterisks) - amount)}"\
                  f"{ASTERISK_TO_PRINT * amount}{SPACE_SEPARATOR}"\
                  f"{ASTERISK_TO_PRINT * amount}")
        for amount in range(int(num_asterisks), 0, -1):
            print(f"{SPACE_SEPARATOR * (int(num_asterisks) - amount)}"\
                  f"{ASTERISK_TO_PRINT * amount}{SPACE_SEPARATOR}"\
                  f"{ASTERISK_TO_PRINT * amount}")
print(PROGRAM_END_MESSAGE)
