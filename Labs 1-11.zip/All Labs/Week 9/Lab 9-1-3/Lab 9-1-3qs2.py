# Lab 9-1-3 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os

AGE_FIRST_CHAR = -2
USER_INITIAL = "Initial"
USER_LNAME = "LastName"
USER_AGE = "Age"

def load_user_data(file_name):
    """
     Reads the 1 line of text in the file specified
     and returns the data it contains as a dictionary.
    """
    file_obj = open(file_name)
    line = file_obj.readline()
     
    data = {USER_INITIAL: line[0],
            USER_LNAME: line[1:AGE_FIRST_CHAR],
            USER_AGE: line[AGE_FIRST_CHAR:]
            }
    file_obj.close()
    return data


def display_user_data(user_info):
    """
        Displays the values in the dictionary
    """
    print(f"Initial of the first name is: {user_info.get(USER_INITIAL)}")
    print(f"The last name is: {user_info.get(USER_LNAME)}")
    print(f"The age is: {user_info.get(USER_AGE)}")
    
    
user_file = "YoungUser.txt"
user_data = load_user_data(user_file)
display_user_data(user_data)

print()

user_file = "OldUser.txt"
user_data = load_user_data(user_file)
display_user_data(user_data)
