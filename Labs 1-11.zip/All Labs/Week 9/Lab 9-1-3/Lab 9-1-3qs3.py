# Lab 9-1-3 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os

USER_INITIAL = "Initial"
USER_LNAME = "LastName"
USER_AGE = "Age"

def display_user_data(user_info):
    """
        Displays the values in the dictionary
    """
    print(f"Initial of the first name is: {user_info.get(USER_INITIAL)}")
    print(f"The last name is: {user_info.get(USER_LNAME)}")
    print(f"The age is: {user_info.get(USER_AGE)}")