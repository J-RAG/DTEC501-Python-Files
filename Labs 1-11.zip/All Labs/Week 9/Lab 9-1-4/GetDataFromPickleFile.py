# Get the Pickle objects from the files specified in the list
# and report on them.
# The load_info function is straight from the files presentation.

import pickle
WRITE_BINARY_MODE = "wb"
READ_BINARY_MODE = "rb"


EXIST_KEY = "DataExists"
LOADED_KEY = "DataLoaded"
NOT_LOADED_KEY = "NotLoaded"
FILE_MISSING_KEY = "FileMissing"
YES_RESPONSE = "Y"

def load_info(file_name):
    READ_BINARY_MODE = "rb"

    file_obj = open(file_name, READ_BINARY_MODE)
    file_data = pickle.load(file_obj) 
    file_obj.close()

    return file_data

def load_data(data_obj, data_file, messages):
    """

    """
    if not os.path.exists(data_file):
        print(messages.get(FILE_MISSING_KEY))
    else:
        file_obj = open(data_file, READ_BINARY_MODE)
        return len(file_obj)
##        if len(file_obj) > 0:
##            response = input(messages.get(EXIST_KEY)).strip().upper()
##            if response != YES_RESPONSE:
##                print(messages.get(NOT_LOADED_KEY))
##    return data_obj    


##filenames = ("ApplesPearsMarmite.p", "MagicRoundabout.p", "MarmiteOnToast.p")
##for pickle_file in filenames:
##    
##    data_from_file = load_info(pickle_file)
##    print()
##    print(f"Reading {pickle_file}")
##    print(f"data_from_file is a {type(data_from_file)} and it contains:")
##    print(data_from_file)
##    print(f"therefore {pickle_file} contains a {type(data_from_file)}.")
    

# Don't load the shopping (list) items from the file
import os
import pickle

# The dictionary contains the messages to be displayed
load_dialogue = {
    "DataExists"  : "Data already exists in the list, overwrite? (Y/N): ",
    "DataLoaded"  : "Shopping list has been loaded.",
    "NotLoaded"   : "Shopping list was not loaded.",
    "FileMissing" : "Shopping file is not present."
    }
    
shopping_list_items = ["Apples", "Pears", "Marmite"]
file_name = "MarmiteOnToast.p"
shopping_items_needed = load_data(data_obj = shopping_list_items, data_file = file_name, messages = load_dialogue)
print(shopping_list_items)
