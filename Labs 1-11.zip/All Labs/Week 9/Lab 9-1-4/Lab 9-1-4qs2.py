# Lab 9-1-4 question 2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

WRITE_BINARY_MODE = "wb"
READ_BINARY_MODE = "rb"

SAVED_KEY = "DataSaved"
NOT_SAVED_KEY = "NotSaved"
FILE_EXISTS_KEY = "FileExists"

EXIST_KEY = "DataExists"
LOADED_KEY = "DataLoaded"
NOT_LOADED_KEY = "NotLoaded"
FILE_MISSING_KEY = "FileMissing"

YES_RESPONSE = "Y"


def save_data(data_obj, data_file, messages):
    """
        Savas Data Via Pickle
    """
    response = ""
    if os.path.exists(data_file):
        # Save Confirmation
        response = input(messages.get(FILE_EXISTS_KEY)).strip().upper()
        if response != YES_RESPONSE:
            print(messages.get(NOT_SAVED_KEY))
    if not os.path.exists(data_file) or response == YES_RESPONSE:
        print(messages.get(SAVED_KEY))
        file_obj = open(data_file, WRITE_BINARY_MODE)
        pickle.dump(data_obj,file_obj)
        file_obj.close()
        return True
    return False

def load_data(data_obj, data_file, messages):
    """
        Loads data via Pickle     
    """
    response = ""
    if os.path.exists(data_file):
        if len(data_obj) != 0:
        # Overwrite confrimation
            response = input(messages.get(EXIST_KEY)).strip().upper()  
    else:
        print(messages.get(FILE_MISSING_KEY))
    if len(data_obj) == 0 or response == YES_RESPONSE:
        print(messages.get(LOADED_KEY))
        file_obj = open(data_file, READ_BINARY_MODE)
        data_obj = pickle.load(file_obj)
        file_obj.close()
    elif (len(data_obj) != 0 and response != YES_RESPONSE) and os.path.exists(data_file):
        print(messages.get(NOT_LOADED_KEY))
        
    return data_obj

# Save the dictionary data to a new file
import os
import pickle

save_dialogue_msgs = {
    "DataSaved" : "The contacts have been saved.",
    "NotSaved"  : "The contacts were not saved.",
    "FileExists" : "The file exists, overwrite? (Y/N): "
    }

load_dialogue_msgs = {
    "DataExists"  : "There are contacts in memory, overwrite? (Y/N): ",
    "DataLoaded"  : "The contacts have been loaded.",
    "NotLoaded"   : "The contacts have not been loaded.",
    "FileMissing" : "The contacts file is not present."
    }
    

contacts = {"Emintrude" : 1001,
            "Florence"  : 1002,
            "Zebedee"   : 1003
            }

file_name = "MagicRoundabout.p"
print(contacts)

saved_status = save_data(data_obj = contacts, data_file = file_name, messages = save_dialogue_msgs)
if saved_status:
    contacts = load_data(data_obj = contacts, data_file = file_name, messages = load_dialogue_msgs)
    print(contacts)
else:
    print("Data was not saved.")
    print(contacts)
