# Lab 9-1-2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os

SINGLE_COMMENT = "comment"
PLURAL_COMMENT = "comments"
SINGLE_LINE = "line"
PLURAL_LINE = "lines"
READ_MODE = "r"
COMMENT_PRESENT = "#"


def analyse_source_code(file_name):
    """
        Checks presence of file if present, counts number of lines
        that contain comments, number of lines that contain code
        and total number of lines in the file.
    """
    comment_lines = 0
    code_lines = 0
    total_lines = 0
    if not os.path.exists(file_name):
        return (f"Sorry, I can't see a file called {file_name}.")
    else:
        file_obj = open(file_name, READ_MODE)
        for line in file_obj:  
            if line.startswith(COMMENT_PRESENT):
                comment_lines += 1
            elif line.strip() != "":
                code_lines += 1
            total_lines += 1
        file_obj.close()
                
        # Output
        # Grammar check
        if (code_lines == 0 or code_lines > 1) and (comment_lines == 0 or comment_lines > 1):
            result = f"{file_name} contains {comment_lines} {PLURAL_COMMENT} and {code_lines} {PLURAL_LINE}"
        elif (comment_lines == 0 or comment_lines > 1) and code_lines == 1:
            result = f"{file_name} contains {comment_lines} {PLURAL_COMMENT} and {code_lines} {SINGLE_LINE}"
        elif (code_lines == 0 or code_lines > 1) and comment_lines == 1:
            result = f"{file_name} contains {comment_lines} {SINGLE_COMMENT} and {code_lines} {PLURAL_LINE}"     
        else:
            result = f"{file_name} contains {comment_lines} {SINGLE_COMMENT} and {code_lines} {SINGLE_LINE}"
            
        if total_lines > 1:
            return f"{result} of code out of {total_lines} {PLURAL_LINE} in total."
        else:
            return f"{result} of code out of {total_lines} {SINGLE_LINE} in total."



test_cases = ("0comments0code1total.txt",
              "0comments1code1total.txt",
              "0comments1code2total.txt",
              "0comments1code4total.txt",
              "0comments3code4total.py",
              "0comments5code5total.txt",
              "1comment0code1total.txt", 
              "1comment0code2total.txt", 
              "1comment1code2total.txt", 
              "1comment3code4total.txt", 
              "1comment10code12total.py",
              "2comments2code6total.txt",
              "3comments2code5total.txt",
              "4comments0code4total.txt",
              "5comments1code7total.txt",
              "NoSuchFile.txt",
)

for test_file in test_cases:
    code_report = analyse_source_code(test_file)
    print(code_report)
