# Lab 9-1-1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os

READ_MODE = "r"
def display_file(filename, line_counter=True,
                 line_length=False, total_count=False):
    """
        Displays the contents of the file specified as per
        the requirements that are specified.
    """    
    file_obj = open(filename, READ_MODE)    

    char_count = 0
    for count, line in enumerate(file_obj, start = 1):
        line = line.replace("\n", "")
        # Line Counter Format
        if line_counter and line_length:
            # Character line Count option
            print(f"{count}: {line} ({len(line)})")
        elif line_counter and not line_length:
            print(f"{count}: {line}")

        # No Line Counter Format  
        elif line_length:
            # Character line Count option
            print(f"{line} ({len(line)})")
        else:
            print(f"{line}".replace("\n", ""))
        char_count += len(line.replace("\n",""))  

    # Total Character Count option
    if total_count:     
        print(f"Total chrs: {char_count}")
    file_obj.close()           


# Test the arguments using a binary pattern
import os
reqd_file = "ReadMe.txt"

bits_reqd = 3
for arg_val in range(0, 2 ** bits_reqd):
    arg_pattern = f"{arg_val:0{bits_reqd}b}"
    display_file(reqd_file, bool(int(arg_pattern[0])), bool(int(arg_pattern[1])), bool(int(arg_pattern[2])))
    print()
        
    

