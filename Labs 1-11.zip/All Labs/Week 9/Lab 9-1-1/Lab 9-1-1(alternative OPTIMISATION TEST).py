# Lab 9-1-1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os

READ_MODE = "r"
def display_file(filename, line_counter=True,
                 line_length=False, total_count=False):
    """
        Displays the contents of the file specified as per
        the requirements that are specified.
    """    
    file_obj = open(filename, READ_MODE)    
    if line_counter and line_length:
        
        for count, line in enumerate(file_obj, start = 1): 
            print(f"{count}: {line} ({len(line)})".replace("\n",""))
    elif line_counter and not line_length:
        for count, line in enumerate(file_obj, start = 1):
            print(f"{count}: {line}".replace("\n", ""))

    
    elif line_length:
        
        for line in file_obj:
            print(f"{line} ({len(line)})".replace("\n",""))
    else:
        for line in file_obj:
            print(f"{line}".replace("\n", ""))
    file_obj.close()

    
    if total_count:
        file_obj = open(filename, READ_MODE)
        char_count = 0
        for line in file_obj:
            char_count += len(line.replace("\n",""))
        print(f"Total chrs: {char_count}".replace("\n", ""))
        file_obj.close() 
            



# Test the arguments using a binary pattern
import os
reqd_file = "ReadMe.txt"

bits_reqd = 3
for arg_val in range(0, 2 ** bits_reqd):
    arg_pattern = f"{arg_val:0{bits_reqd}b}"
    display_file(reqd_file, bool(int(arg_pattern[0])), bool(int(arg_pattern[1])), bool(int(arg_pattern[2])))
    print()

    
   
        
    

