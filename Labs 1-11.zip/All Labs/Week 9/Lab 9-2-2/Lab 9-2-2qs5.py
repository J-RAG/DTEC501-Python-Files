# Lab 9-2-1 question 5
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def remove_directory(dir_name):
    """
        If the specified directory is present and is empty
        then directory is removed, informs the user and returns True.
        If it's not empty then directory is not removed and returns
        False. The User is informed in each case.

        If the Specified Directory doesnt exist then user is informed
        and returns False.
    """
    # Check if Directory Exists
    if not os.path.exists(dir_name):
        print(f"Sorry, {dir_name} does not exist.")
    else:
        curr_dir = os.getcwd()
        # Check if directory is empty
        if len(os.listdir(curr_dir + f"/{dir_name}")) > 0:
            print(f"Can't remove {dir_name} because it is not empty.")
        # Go Back and remove directory
        else:
            os.rmdir(dir_name)
            print(f"{dir_name} has been removed.")
            return True
    return False
    


### Attempt to remove a non present directory
##import os
##directory_name = "NotPresent"
##return_status = remove_directory(directory_name)
##print(return_status)


## Attempt to remove a present directory that contains a subordinate directory
## The current working directory contains "Already" and inside that is a directory called "Present"
## We can't remove "Already"

import os
os.mkdir("Already")
os.mkdir("Already/Present")

directory_name = "Already"
return_status = remove_directory(directory_name)
print(return_status)

## Attempt to remove the subordinate's subordinate directory "Already/Present" 
## The current working directory contains "SourceCode" and inside that is a directory called "Python"
## We can remove "SourceCode/Python"

##import os
##os.mkdir("SourceCode")
##os.mkdir("SourceCode/Python")
##
##directory_name = "SourceCode/Python"
##return_status = remove_directory(directory_name)
##print(return_status)
##
### We can now remove SourceCode
### Attempt to remove the subordinate directory "SourceCode" 
##directory_name = "SourceCode"
##return_status = remove_directory(directory_name)
##print(return_status)

