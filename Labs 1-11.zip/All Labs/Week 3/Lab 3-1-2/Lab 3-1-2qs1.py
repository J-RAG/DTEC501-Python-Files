# Lab 3-1-2 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

beach_response = input("Would you like to go to the beach? (y/n) ").strip().lower()
weekend_response = input("Is it the weekend?  (y/n) ").strip().lower()
result = beach_response == "y" and weekend_response == "y"
print(f"It is {str(result).lower()} that you can go to the beach today.")
