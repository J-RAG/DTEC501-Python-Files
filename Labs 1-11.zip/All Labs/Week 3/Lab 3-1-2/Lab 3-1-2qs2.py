# Lab 3-1-2 question 2
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

beach_response = input("Would you like to go to the beach? (y/n) ").strip().lower()
saturday_response = input("Is it Saturday? (y/n) ").strip().lower()
sunday_response = input("Is it Sunday? (y/n) ").strip().lower()
is_tideout = input("Is the tide out? (y/n) ").strip().lower()

beach_result = beach_response.lower() == "y"
weekend_result = (saturday_response.lower() == "y") or (sunday_response.lower() == "y")
invalid_flag = not((saturday_response.lower() == "y") and (sunday_response.lower() == "y"))
tideout_result = is_tideout.lower() == "y"
final_result = beach_result and weekend_result and invalid_flag and tideout_result

print()
print(f"It is {str(final_result).lower()} that you can go to the beach today.")
