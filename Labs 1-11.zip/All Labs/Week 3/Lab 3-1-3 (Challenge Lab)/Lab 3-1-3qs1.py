# Lab 3-1-3 question 1 CHALLENGE LAB
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz


#input phase#
print("The pizza chooser.")
vegy_resp = input("Are you a vegetarian? ").strip().lower()
vegn_resp = input("Are you a vegan? ").strip().lower()
meat_resp = input("Are you a meat eater? ").strip().lower()
eat_pizza_flag = input("Would you like to eat a pizza? ").strip().lower()

#logic phase
#who are you
vegy_result = ((vegy_resp.lower().startswith("y")) and \
               ((not(vegn_resp.lower().startswith("y"))) and (not(meat_resp.lower().startswith("y"))))\
              ) and eat_pizza_flag.lower().startswith("y")

vegn_result = (((vegn_resp.lower().startswith("y") and not (vegy_resp.lower().startswith("y"))) or\
               (not (vegn_resp.lower().startswith("y")) and (vegy_resp.lower().startswith("y")))) and\
               (not (meat_resp.lower().startswith("y"))) and eat_pizza_flag.lower().startswith("y"))

meat_result = ((meat_resp.lower().startswith("y")) and \
               (not(vegy_resp.lower().startswith("y"))) and (not(vegn_resp.lower().startswith("y"))))\
               and eat_pizza_flag.lower().startswith("y")

#output
print()
print(f"It is {str(vegy_result).lower()} that you would like a veggie pizza.")
print(f"It is {str(vegn_result).lower()} that you would like a vegan pizza.")
print(f"It is {str(meat_result).lower()} that you would like a carnivore pizza.")

