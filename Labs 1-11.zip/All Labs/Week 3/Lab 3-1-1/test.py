prefers_web_dev = "y" in input("Would you like to study Web Dev? (y/n) ").strip().lower()
prefers_tech_support = "y" in input("Would you like to study Tech Support? (y/n) ").strip().lower()

course_available = prefers_web_dev or prefers_tech_support
print(f"It is {course_available} that we have a course suitable for you.")
