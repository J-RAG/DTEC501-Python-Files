# Lab 9-1-3 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os

AGE_FIRST_CHAR = -2
USER_INITIAL = "Initial"
USER_LNAME = "LastName"
USER_AGE = "Age"

def load_user_data(file_name):
    """
     Reads the 1 line of text in the file specified
     and returns the data it contains as a dictionary.
    """
    file_obj = open(file_name)
    line = file_obj.readline()
     
    data = {USER_INITIAL:line[0],
            USER_LNAME : line[1:AGE_FIRST_CHAR],
            USER_AGE : line[AGE_FIRST_CHAR:]
            }
    file_obj.close()
    return data

user_file = "OldUser.txt"
user_data = load_user_data(user_file)

if isinstance(user_data, dict):
    print(user_data)
else:
    print("The function did not return a dictionary. :-(")
