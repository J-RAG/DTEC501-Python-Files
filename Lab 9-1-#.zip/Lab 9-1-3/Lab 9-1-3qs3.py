# Lab 9-1-3 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os
