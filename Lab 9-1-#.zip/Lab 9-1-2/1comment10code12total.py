today = "Friday"
minimum_temperature = 10
current_temperature = 20

if today.lower().endswith("y"):
    if current_temperature >= minimum_temperature:
        print("It's time to go to the beach!")
    else:
        print("It's not warm enough to go to the beach. :-(")
else:
    print("I think we should go to the beach anyway. :)")
# end of program