def say_oook():
    return "Oook!"

print(f"This is our first function {say_oook()}")