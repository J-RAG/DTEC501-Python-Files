# Lab 9-1-4 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

WRITE_BINARY_MODE = "wb"
READ_BINARY_MODE = "rb"


EXIST_KEY = "DataExists"
LOADED_KEY = "DataLoaded"
NOT_LOADED_KEY = "NotLoaded"
FILE_MISSING_KEY = "FileMissing"
YES_RESPONSE = "Y"


def load_data(data_obj, data_file, messages):
    """
        Loads data via Pickle     
    """
    response = ""
    if os.path.exists(data_file):
        if len(data_obj) != 0:
        # Overwrite confrimation
            response = input(messages.get(EXIST_KEY)).strip().upper()  
    else:
        print(messages.get(FILE_MISSING_KEY))
    if len(data_obj) == 0 or response == YES_RESPONSE:
        print(messages.get(LOADED_KEY))
        file_obj = open(data_file, READ_BINARY_MODE)
        data_obj = pickle.load(file_obj)
        file_obj.close()
    elif (len(data_obj) != 0 and response != YES_RESPONSE) and os.path.exists(data_file):
        print(messages.get(NOT_LOADED_KEY))
        
    return data_obj
    
# Save the list data to a new file
import os
import pickle

save_dialogue = {
    "DataSaved" : "The shopping list has been saved.",
    "NotSaved"  : "The shopping list was not saved.",
    "FileExists" : "The file exists, overwrite? (Y/N): "
    }

load_dialogue = {
    "DataExists"  : "Data already exists in the list, overwrite? (Y/N): ",
    "DataLoaded"  : "Shopping list has been loaded.",
    "NotLoaded"   : "Shopping list was not loaded.",
    "FileMissing" : "Shopping file is not present."
    }

items_needed = ["Apples", "Pears", "Marmite"]
print(items_needed)
file_name = "ApplesPearsMarmiteTest1.p"
saved_status = save_data(data_obj = items_needed, data_file = file_name, messages = save_dialogue)
if saved_status:
    loaded_data = load_data(data_obj = items_needed, data_file = file_name, messages = load_dialogue)
    print(loaded_data)
else:
    print("Data was not saved.")
    print(items_needed)
