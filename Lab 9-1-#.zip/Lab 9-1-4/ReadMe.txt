Reading ApplesPearsMarmite.p
data_from_file is a <class 'list'> and it contains:
['Apples', 'Pears', 'Marmite']
therefore ApplesPearsMarmite.p contains a <class 'list'>.

Reading MagicRoundabout.p
data_from_file is a <class 'dict'> and it contains:
{'Emintrude': 1001, 'Florence': 1002, 'Zebedee': 1003, 'Dougal': 1004}
therefore MagicRoundabout.p contains a <class 'dict'>.

Reading MarmiteOnToast.p
data_from_file is a <class 'list'> and it contains:
['Bread', 'Butter', 'Marmite']
therefore MarmiteOnToast.p contains a <class 'list'>.