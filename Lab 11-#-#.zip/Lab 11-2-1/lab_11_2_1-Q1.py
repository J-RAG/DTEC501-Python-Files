# lab 11-2-1 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
import lab_11_1_2_module

user_response = input("Please enter a phrase: ").strip()
if lab_11_1_2_module.is_reversible(user_response):
    print(f"{user_response} is a palindrome.")
else:
    print(f"{user_response} is not a palindrome.")
