# Lab 11-3-1 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import sys
result = len(sys.argv) - 1
if result != 1:
    print(f"{result} arguments.")
else:
    print(f"{result} argument.")
