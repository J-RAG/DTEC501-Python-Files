# Lab 11-3-1 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import sys

if len(sys.argv) - 1 != 2:
    print("Incorrect number of arguments supplied.")
elif not all([sys.argv[1].isdigit(), sys.argv[2].isdigit()]):
    print("Integer values only please")
else:
    result = int(sys.argv[1]) ** int(sys.argv[2])
    print(f"{sys.argv[1]} to the power of {sys.argv[2]} is {result}")


