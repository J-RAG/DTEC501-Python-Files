# Lab 11-1-2 question 1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

FULLSTOP_CHAR = "."
def is_reversible(phrase):
    """
        returns True if the value is palindromic
        and False if it is not palindromic.
    """
    # remove string spaces and fullstops 
    char = str(phrase).replace(" ","").replace(FULLSTOP_CHAR,"").lower()
    return char == char[::-1]


# Empty sting
test_value = ""
palindromic = is_reversible(test_value)
print(palindromic)

# Numeric value
test_value = 121
palindromic = is_reversible(test_value)
print(palindromic)


# Single alphabetic char string
test_value = "A"
palindromic = is_reversible(test_value)
print(palindromic)


# Not palindromic string
test_value = "Not"
palindromic = is_reversible(test_value)
print(palindromic)


# Long mixed case palindromic string
test_value = "Was it a car or a cat I saw"
palindromic = is_reversible(test_value)
print(palindromic)

	
# Empty sting
test_value = ""
palindromic = is_reversible(test_value)
print(palindromic)
