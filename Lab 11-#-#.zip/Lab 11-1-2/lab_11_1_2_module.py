# lab_11_1_2_module.py
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def is_reversible(phrase):
    """
        returns True if the value is palindromic
        and False if it is not palindromic.
    """
    # remove string spaces and fullstops 
    char = str(phrase).replace(" ","").replace(".","").lower()
    return char == char[::-1]
