from Lab11_1Functions import *

from Lab11_1Functions import starts_with_capital

print(convert_to_celsius(50))
