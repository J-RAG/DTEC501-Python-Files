# DTEC Assesment 2 Question: 3
# By Julan Ray Avila Gutierrez jra0108@arastudent.ac.nz LG-A

import os
WRITE_BINARY_MODE = "wb"
def save_best_player(player_details, game_file):
    """
        writes the details of the best player to a file. 
    """
    player_info = {
        'player_name' : player_details[0],
        'player_score' : player_details[1],
        'difficulty' : player_details[-1]
        }
    try:
        file_obj = open(game_file, WRITE_BINARY_MODE)
        pickle.dump(player_info, file_obj ) 
        file_obj.close()
    except:
        return (False, "An error occurred while saving the game file.")
         
    else:
        return (True, "Game file saved.")
        

# Unsuccessful saving of the game file

import pickle

READ_BINARY_MODE = "rb"

# Game player details
play_name = "b35tPl@y3r"
guesses_used = 6
game_level = 1

best_player_file = "X:/BestPlayer.p"

return_value = save_best_player((play_name, guesses_used, guesses_used), best_player_file)
print(f"Function returned {type(return_value)}: {return_value}")

if return_value[0] is True:
    # Get the object from the pickle file and display it
    file_handle = open(best_player_file, READ_BINARY_MODE)
    game_data = pickle.load(file_handle)
    print(f"Game file contains a {type(game_data)}: {game_data}")
    file_handle.close()
else:
    print(f"The error message is: {return_value[1]}")
