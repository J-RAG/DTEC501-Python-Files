# DTEC Assesment 2 Question: 1
# By Julan Ray Avila Gutierrez jra0108@arastudent.ac.nz LG-A
import sys
if len(sys.argv) == 2:
    if sys.argv[1].isdigit():
        number = int(sys.argv[1])
        print(f"{number} decimal\nhex: {hex(number)}\noctal: {oct(number)}\nbinary: {bin(number)}")
    else:
        print("The value must be an unsigned integer.")
else:
    print("Usage: ConvertFromDecimal <value>\nThe value must be an unsigned integer.")
