# DTEC Assesment 2 Question: 2
# By Julan Ray Avila Gutierrez jra0108@arastudent.ac.nz LG-A

def display_investment(investment_amount,
                       investment_period,
                       annual_interest):
    """
        displays the monthly balance of an amount invested
        in a bank for a specified monthly period and interest rate.
    """


    monthly_interest = annual_interest / 12
    print(f"Investment amount: {investment_amount:.2f}")
    print(f"Investment period: {investment_period} months")
    print(f"Monthly interest: {monthly_interest}%")
    print()
    # Initial Balance and interest at the start
    month_balance = investment_amount
    interest_earned = monthly_interest 
    for month in range(1, investment_period + 1):
        month_balance =   month_balance + interest_earned
        print(f"Month #: {month}.  Start of month balance: ${investment_amount:.2f}  Interest: {interest_earned:.2f}  End of month balance: ${month_balance:.2f}")
        interest_earned = (month_balance * monthly_interest) / 100
    print(f"Profit: ${month_balance-investment_amount:.2f}")

display_investment(investment_amount = 100, investment_period = 12, annual_interest = 12)
