# Lab 9-2-2 question 3
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def get_dir_name(action):
    """
        Requests input returns the entered directory name as a string
    """

    return input(f"Please enter the name of the directory to be {action}: ").strip()
