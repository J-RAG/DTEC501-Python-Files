# Lab 9-2-2 question 4
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

def make_directory(dir_name):
    """
        Creates the specified directory if the directory is not present,
        informs the user it has been created and returns True. If the specified
        directory is present, make_directory inform the user the directory is
        already present and returns False.
    """
    if os.path.exists(dir_name):
        print(f"Sorry, {dir_name} is already present.")
        return False
    os.mkdir(dir_name)
    print(f"{dir_name} has been created.")
    return True
	
	
import os
directory_name = "NotPresent/AboutToBeCreated"
return_status = make_directory(directory_name)
print(return_status)
