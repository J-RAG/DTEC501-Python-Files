# Lab 9-2-1 question 6
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz

import os
MENU = [
    "M) Make a directory.",
    "R) Remove a directory.",
    "E) Exit."
    ]

MAKE_DIR = "m"
REMOVE_DIR = "r"
EXIT_PROG = "e"
MK_ACTION = "created"
RM_ACTION = "removed"

EMPTY_LIST_MSG = "Sorry, the list is empty."
EXIT_MSG = "Bye."

def display_list(generic_list, counter_reqd=True):
    """
        Display lists of items
        If required display items in a numbered format
    """
    # Check if list is Empty
    if len(generic_list) == 0:
        print(EMPTY_LIST_MSG)
        return False 
                
    else:
        # Display List
        print()
        for count, item in enumerate(generic_list, start = 1):
            # Numbered Format Check
            print(f"Item {count}: {item}" if counter_reqd else item)
        return True


def get_option():
    """
        Asks the user to enter an option, removes any extra spaces,
        converts the entered text into lower case and returns it as a string.
    """
    return input("Option: ").strip().lower()


def get_dir_name(action):
    """
        Requests input returns the entered directory name as a string
    """
    return input(f"Please enter the name of the directory to be {action}: ").strip()


def make_directory(dir_name):
    """
        Creates the specified directory if the directory is not present,
        informs the user it has been created and returns True. If the specified
        directory is present, make_directory inform the user the directory is
        already present and returns False.
    """
    curr_dir = os.getcwd()
    if os.path.exists(dir_name):
        print(f"Sorry, {dir_name} is already present.")
        return False
    os.mkdir(dir_name)
    print(f"{dir_name} has been created.")
    return True


def remove_directory(dir_name):
    """
        If the specified directory is present and is empty
        then directory is removed, informs the user and returns True.
        If it's not empty then directory is not removed and returns
        False. The User is informed in each case.

        If the Specified Directory doesnt exist then user is informed
        and returns False.
    """
    # Check if Directory Exists
    if not os.path.exists(dir_name):
        print(f"Sorry, {dir_name} does not exist.")
    else:
        curr_dir = os.getcwd()
        # Check if directory is empty
        if len(os.listdir(curr_dir + f"/{dir_name}")) > 0:
            print(f"Can't remove {dir_name} because it is not empty.")
        # Go Back and remove directory
        else:
            os.rmdir(dir_name)
            print(f"{dir_name} has been removed.")
            return True
    return False

option = ""
action ={
    MAKE_DIR: MK_ACTION,
    REMOVE_DIR: RM_ACTION,
    }

while option != EXIT_PROG:
    display_list(MENU, False)
    option = get_option()
    if option in action and option == MAKE_DIR:
        make_directory(get_dir_name(action[option]))
    elif option in action and option == REMOVE_DIR:
        remove_directory(get_dir_name(action[option]))
print(EXIT_MSG)




