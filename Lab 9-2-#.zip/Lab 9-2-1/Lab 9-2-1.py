# Lab 9-2-1
# By Julan Ray Avila Gutierrez, jra0108@arastudent.ac.nz
import os

DIR_ID = "directory"
FILE_ID = "file"

curr_dir = os.getcwd()
# Get directory length 
dir_contents = os.listdir(curr_dir)
if len(dir_contents) == 1:
    print(f"There is {len(dir_contents)} item in your current working directory.")
else:
    print(f"There are {len(dir_contents)} items in your current working directory.")

# Get directory listing 
for list_num, dir_entry in enumerate(dir_contents, start=1):
    # Identify if item is a file or a directory
    if os.path.isdir(dir_entry):
        print(f"{list_num}: {dir_entry} is a {DIR_ID}.")
    else:
        print(f"{list_num}: {dir_entry} is a {FILE_ID}.")
